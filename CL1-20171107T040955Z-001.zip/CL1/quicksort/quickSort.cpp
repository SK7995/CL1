#include <iostream>
#include <stdlib.h>
#include <ctime>
#include <time.h>
#include <omp.h>
#include <fstream>
using namespace std;

int a[10000];
int comparision = 0;


void display(int n){
	for(int i=0;i<n;i++){
		cout<<a[i];
		cout<<"\t";
	}
}

int partition(int low, int high){
	int pivot = a[high]; 
	int i = low - 1;
	#pragma omp parallel for 
	for(int j = low ; j <= high-1 ; j++){
		if(a[j] <= pivot){
			i++;
			swap(a[i],a[j]);
		}
	}
	swap(a[i+1], a[high]);
	return i+1;
}

void quickSort(int low, int high){
	if(low < high){
		int index = partition(low, high);
		quickSort(low, index-1);
		quickSort(index+1, high);
	}
}

void swap(int a,int b){
	int temp;
	if(a > b){
	    temp = a;
	    a = b;
	    b = temp;
	}
}

int main() {
	int n,i,ch;
	float time_elapsed;
	ofstream myfile;

	cout<<"\nEnter how many elements: ";
	cin>>n;

	for(i=0;i<n;i++){
			a[i] = (rand() % 10000) + 1;
	}

	cout<<"\n\nYour pivot element is by default the last element: "<<a[n-1];
	myfile.open("output.txt");

	cout<<"\n\nThe entered list is: \n";
	display(n);

	clock_t c_start = clock();
	quickSort(0,n-1);
	clock_t c_end = clock();
	time_elapsed = (c_end - c_start);
	
	cout<<"\n\nThe sorted list is: \n";
	display(n);

	for(i=0;i<n;i++){
		myfile<<a[i]<<"\t";
	}

	cout<<"\n\nCPU time = "<<time_elapsed<<" msecs";
	cout<<"\n\n";
	return 0;
}

/* OUTPUT----------------------------------------

sachin@sachin-desktop:~/Documents$ g++ quickSort.cpp -fopenmp
sachin@sachin-desktop:~/Documents$ ./a.out

Enter how many elements: 7   


Your pivot element is by default the last element: 5387

The entered list is: 
9384	887	2778	6916	7794	8336	5387	

The sorted list is: 
887	2778	5387	6916	7794	8336	9384	

CPU time = 2 msecs

sachin@sachin-desktop:~/Documents$ cat output.txt

887	2778	5387	6916	7794	8336	9384
*/
