
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.vq import kmeans2, whiten

data=[]

raw_file=open("dataset.csv","r")
lines=raw_file.readlines()
for x in lines:
	abc=[]
	temp=x.split(',')
	print temp
	#temp[3]=temp[3].replace(',')
	abc.append(int(temp[0]))
	abc.append(int(temp[1]))
	abc.append(int(temp[2]))
	abc.append(int(temp[3]))
	data.append(abc)

x, y = kmeans2(whiten(data), 3, iter = 1000)
noofsamplesincluster1=0
noofsamplesincluster2=0
noofsamplesincluster3=0

for n in xrange(len(y)):
	if y[n]==0:
		noofsamplesincluster1+=1
	if y[n]==1:
		noofsamplesincluster2+=1
	if y[n]==2:
		noofsamplesincluster3+=1
print "Cluster 1 = ",noofsamplesincluster1,"Cluster 2 = ",noofsamplesincluster2,"Cluster 3 = ",noofsamplesincluster3
print "Cluster 1"



for n in xrange(len(y)):
	if y[n]==0:
		print "Height: ",data[n][0],"Weight: ",data[n][1],"Age: ",data[n][2],"IQ: ",data[n][3]
		print "Cluster 2"
for n in xrange(len(y)):
	if y[n]==1:
		print "Height: ",data[n][0],"Weight: ",data[n][1],"Age: ",data[n][2],"IQ: ",data[n][3]
		print "Cluster 3"
for n in xrange(len(y)):
	if y[n]==2:
		print "Height: ",data[n][0],"Weight: ",data[n][1],"Age: ",data[n][2],"IQ: ",data[n][3]
		height=[]
		weight=[]
for p in data:
	height.append(p[0])
	weight.append(p[1])
	plt.scatter(height, weight)
	plt.show()


"""[fedora@localhost Documents]$ python student.py 
['130', '30', '10', '70\n']
['140', '36', '12', '76\n']
['131', '31', '10', '71\n']
['133', '33', '11', '73\n']
['141', '37', '12', '76\n']
['134', '34', '11', '74\n']
['142', '38', '12', '77\n']
['135', '35', '11', '75\n']
['132', '32', '10', '72\n']
['139', '35', '12', '75\n']
['132', '32', '11', '72\n']
['129', '29', '10', '69\n']
['138', '34', '12', '74\n']
['113', '19', '6', '61\n']
['116', '21', '7', '62\n']
['114', '20', '6', '59\n']
['121', '24', '8', '65\n']
['111', '17', '6', '61\n']
['117', '22', '7', '63\n']
['122', '25', '8', '66\n']
['115', '20', '7', '61\n']
['112', '18', '6', '60\n']
['120', '23', '8', '64\n']
['124', '27', '9', '68\n']
['123', '26', '8', '67\n']
['118', '23', '7', '64\n']
['125', '28', '9', '69\n']
['144', '39', '13', '80\n']
['148', '42', '14', '82\n']
['155', '45', '15', '85\n']
['145', '40', '13', '81\n']
['149', '43', '14', '83\n']
['146', '41', '13', '82\n']
['156', '46', '15', '86\n']
['150', '44', '14', '84\n']
['157', '47', '15', '87\n']
['154', '44', '15', '84\n']
['153', '43', '15', '83\n']
['143', '38', '13', '79\n']
['147', '41', '14', '81\n']
Cluster 1 =  14 Cluster 2 =  13 Cluster 3 =  13
Cluster 1
Height:  113 Weight:  19 Age:  6 IQ:  61
Cluster 2
Height:  116 Weight:  21 Age:  7 IQ:  62
Cluster 2
Height:  114 Weight:  20 Age:  6 IQ:  59
Cluster 2
Height:  121 Weight:  24 Age:  8 IQ:  65
Cluster 2
Height:  111 Weight:  17 Age:  6 IQ:  61
Cluster 2
Height:  117 Weight:  22 Age:  7 IQ:  63
Cluster 2
Height:  122 Weight:  25 Age:  8 IQ:  66
Cluster 2
Height:  115 Weight:  20 Age:  7 IQ:  61
Cluster 2
Height:  112 Weight:  18 Age:  6 IQ:  60
Cluster 2
Height:  120 Weight:  23 Age:  8 IQ:  64
Cluster 2
Height:  124 Weight:  27 Age:  9 IQ:  68
Cluster 2
Height:  123 Weight:  26 Age:  8 IQ:  67
Cluster 2
Height:  118 Weight:  23 Age:  7 IQ:  64
Cluster 2
Height:  125 Weight:  28 Age:  9 IQ:  69
Cluster 2
Height:  130 Weight:  30 Age:  10 IQ:  70
Cluster 3
Height:  140 Weight:  36 Age:  12 IQ:  76
Cluster 3
Height:  131 Weight:  31 Age:  10 IQ:  71
Cluster 3
Height:  133 Weight:  33 Age:  11 IQ:  73
Cluster 3
Height:  141 Weight:  37 Age:  12 IQ:  76
Cluster 3
Height:  134 Weight:  34 Age:  11 IQ:  74
Cluster 3
Height:  142 Weight:  38 Age:  12 IQ:  77
Cluster 3
Height:  135 Weight:  35 Age:  11 IQ:  75
Cluster 3
Height:  132 Weight:  32 Age:  10 IQ:  72
Cluster 3
Height:  139 Weight:  35 Age:  12 IQ:  75
Cluster 3
Height:  132 Weight:  32 Age:  11 IQ:  72
Cluster 3
Height:  129 Weight:  29 Age:  10 IQ:  69
Cluster 3
Height:  138 Weight:  34 Age:  12 IQ:  74
Cluster 3
Height:  144 Weight:  39 Age:  13 IQ:  80
Height:  148 Weight:  42 Age:  14 IQ:  82
Height:  155 Weight:  45 Age:  15 IQ:  85
Height:  145 Weight:  40 Age:  13 IQ:  81
Height:  149 Weight:  43 Age:  14 IQ:  83
Height:  146 Weight:  41 Age:  13 IQ:  82
Height:  156 Weight:  46 Age:  15 IQ:  86
Height:  150 Weight:  44 Age:  14 IQ:  84
Height:  157 Weight:  47 Age:  15 IQ:  87
Height:  154 Weight:  44 Age:  15 IQ:  84
Height:  153 Weight:  43 Age:  15 IQ:  83
Height:  143 Weight:  38 Age:  13 IQ:  79
Height:  147 Weight:  41 Age:  14 IQ:  81
"""
