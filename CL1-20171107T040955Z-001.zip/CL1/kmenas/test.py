import matplotlib.pyplot as plt
import math

data = [[1.0,1.0], [1.5,2.0], [3.0,4.0], [5.0,7.0], [3.5,5.0], [4.5,5.0], [3.5, 4.5]]

cluster_centers = [[3.5,4.0], [5.5,6.5]]
prev_cluster_centers = [[0.0,0.0], [0.0,0.0]]

list2 = []
list3 = []
list4 = []
list5 = []

for i in data:
	list2.append(i[0])
	list3.append(i[1])

for j in cluster_centers:
	list4.append(j[0])
	list5.append(j[1])

plt.plot(list2,list3,'ro')
plt.plot(list4,list5,'bx')
plt.axis([0,10,0,10])
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Daku')
plt.show()


while prev_cluster_centers != cluster_centers:

	distances = []

	for i in data:
		list1 = []
		for j in cluster_centers:
			t = math.sqrt((math.pow((i[0]-j[0]),2)) + (math.pow((i[1]-j[1]),2)))
			list1.append(t)
		distances.append(list1)

	print (distances)
	first_cluster = []
	second_cluster = []

	for i in range (0,len(distances)):
		t = (min(distances[i]))
		f = distances[i].index(t)
		if f == 0:
			first_cluster.append(data[i])
		else:
			second_cluster.append(data[i])

	list2 = []
	list3 = []
	list4 = []
	list5 = []

	for i in first_cluster:
		list2.append(i[0])
		list3.append(i[1])

	for i in second_cluster:
		list4.append(i[0])
		list5.append(i[1])


	plt.plot(list2,list3,'ro')
	plt.plot(list4,list5,'bo')
	plt.plot([cluster_centers[0][0]],[cluster_centers[0][1]],'rx')
	plt.plot([cluster_centers[1][0]],[cluster_centers[1][1]],'bx')
	plt.axis([0,10,0,10])
	plt.xlabel('Feature 1')
	plt.ylabel('Feature 2')
	plt.title('Cluster assignment')
	plt.show()

	shifted_cluster_centers = []

	len1 = len(first_cluster)
	len2 = len(second_cluster)

	list6 = []
	list7 = []

	sum1 = 0
	sum2 = 0

	for i in first_cluster:
		sum1 += i[0]
		sum2 += i[1]

	list6.append(float(sum1)/float(len1))
	list6.append(float(sum2)/float(len1))
	shifted_cluster_centers.append(list6)

	sum1 = 0
	sum2 = 0

	for i in second_cluster:
		sum1 += i[0]
		sum2 += i[1]

	list7.append(float(sum1)/float(len2))
	list7.append(float(sum2)/float(len2))
	shifted_cluster_centers.append(list7)

	prev_cluster_centers = cluster_centers
	cluster_centers = shifted_cluster_centers

	plt.plot(list2,list3,'ro')
	plt.plot(list4,list5,'bo')
	plt.plot([cluster_centers[0][0]],[cluster_centers[0][1]],'rx')
	plt.plot([cluster_centers[1][0]],[cluster_centers[1][1]],'bx')
	plt.axis([0,10,0,10])
	plt.xlabel('Feature 1')
	plt.ylabel('Feature 2')
	plt.title('Cluster shift')
	plt.show()