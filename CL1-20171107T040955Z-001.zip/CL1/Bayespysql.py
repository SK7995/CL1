#Program to find (Age < 30, Income = medium, student = yes, credit rating = fair)


import MySQLdb
import mysql.connector
import sys

db = MySQLdb.connect("localhost","root", "root@1234", "naivebayes")

cursor = db.cursor()

cursor.execute("SELECT * FROM bayes")         

#data = cursor.fetchall()
#print data      

len_entries = 0

yes_entries = 0
no_entries = 0

less_30_yes = 0
thirty_forty_yes = 0
gt_forty_yes = 0
less_30_no = 0
thirty_forty_no = 0
gt_forty_no = 0

med_yes = 0
high_yes = 0
low_yes = 0
med_no = 0
high_no = 0
low_no = 0

student_yes_yes = 0
student_no_yes = 0
student_yes_no = 0
student_no_no = 0

fair_yes = 0
excel_yes = 0
fair_no = 0
excel_no = 0


for row in cursor:
	len_entries+=1
	
for row in cursor:
	if 'yes' in row[4]:
		yes_entries+=1
	else:
		no_entries+=1
		
print 'Number of YES entries: ',yes_entries
print 'Number of NO entries: ',no_entries

for row in cursor:
	if '<=30' in row[0] and 'yes' in row[4]:
		less_30_yes+=1
	if '31..40' in row[0] and 'yes' in row[4]:
		thirty_forty_yes+=1
	if '>40' in row[0] and 'yes' in row[4] :
		gt_forty_yes+=1
	if '<=30' in row[0] and 'no' in row[4]:
		less_30_no+=1
	if '31..40' in row[0] and 'no' in row[4]:
		thirty_forty_no+=1
	if '>40' in row[0] and 'no' in row[4] :
		gt_forty_no+=1

for row in cursor:
	if 'low' in row[1] and 'yes' in row[4]:
		low_yes+=1
	if 'medium' in row[1] and 'yes' in row[4]:
		med_yes+=1
	if 'high' in row[1] and 'yes' in row[4] :
		high_yes+=1
	if 'low' in row[1] and 'no' in row[4]:
		low_no+=1
	if 'medium' in row[1] and 'no' in row[4]:
		med_no+=1
	if 'high' in row[1] and 'no' in row[4] :
		high_no+=1	

for row in cursor:
	if 'yes' in row[2] and 'yes' in row[4]:
		student_yes_yes+=1
	if 'no' in row[2] and 'yes' in row[4]:
		student_no_yes+=1
	if 'yes' in row[2] and 'no' in row[4]:
		student_yes_no+=1
	if 'no' in row[2] and 'no' in row[4] :
		student_no_no+=1

for row in cursor:
	if 'fair' in row[3] and 'yes' in row[4]:
		fair_yes+=1
	if 'excel' in row[3] and 'yes' in row[4]:
		excel_yes+=1
	if 'fair' in row[3] and 'no' in row[4] :
		fair_no+=1
	if 'excel' in row[3] and 'no' in row[4]:
		excel_no+=1


print '--------------------NAIVE BAYES CLASSIFICATION SYSTEM------------------------'
print 'Age options:- <=30 | 31..40 | >40'
age = raw_input('Give age: ')
print 'Income options:- high | medium | low'
income = raw_input('Give income: ')
print 'Student options:- yes | no'
student = raw_input('Give student (Yes/No): ')
print 'Credit rating options:- fair | excellent'
crd_rating = raw_input('Give credit rating: ')

if '<=30' in age:
	a_yes = float(less_30_yes)/float(yes_entries)
elif '31..40' in age:
	a_yes = float(thirty_forty_yes)/float(yes_entries)
elif '>40' in age:
	a_yes = float(gt_forty_yes)/float(yes_entries)

if '<=30' in age:
	a_no = float(less_30_no)/float(no_entries)
elif '31..40' in age:
	a_no = float(thirty_forty_no)/float(no_entries)
elif '>40' in age:
	a_no = float(gt_forty_no)/float(no_entries)


if 'low' in income:
	i_yes = float(low_yes)/float(yes_entries)
elif 'med' in income:
	i_yes = float(med_yes)/float(yes_entries)
elif 'high' in income:
	i_yes = float(high_yes)/float(yes_entries)

if 'low' in income:
	i_no = float(low_no)/float(no_entries)
elif 'med' in income:
	i_no = float(med_no)/float(no_entries)
elif 'high' in income:
	i_no = float(high_no)/float(no_entries)


if 'yes' in student:
	s_yes = float(student_yes_yes)/float(yes_entries)
elif 'no' in student:
	s_yes = float(student_no_yes)/float(yes_entries)

if 'yes' in student:
	s_no = float(student_yes_no)/float(no_entries)
elif 'no' in student:
	s_no = float(student_no_no)/float(no_entries)


if 'fair' in crd_rating:
	c_yes = float(fair_yes)/float(yes_entries)
elif 'excel' in crd_rating:
	c_yes = float(excel_yes)/float(yes_entries)

if 'fair' in crd_rating:
	c_no = float(fair_no)/float(no_entries)
elif 'excel' in crd_rating:
	c_no = float(excel_no)/float(no_entries)


p_yes = float(yes_entries)/float(len_entries)
p_no = float(no_entries)/float(len_entries)

p_buys_comp_yes = float(a_yes * i_yes * c_yes * s_yes * p_yes)
print p_buys_comp_yes
p_buys_comp_no = float(a_no * i_no * c_no * s_no * p_no)
print p_buys_comp_no

if p_buys_comp_yes > p_buys_comp_no:
	print 'You can buy a Computer!'
else:
	print 'You cannot buy a Computer!'

db.close()

"""------------------------------OUTPUT-----------------------------

Database - 

MariaDB [naivebayes]> select * from bayes;
+--------+--------+---------+---------------+------+
| age    | income | student | credit_rating | buys |
+--------+--------+---------+---------------+------+
| <=30   | high   | no      | fair          | no   |
| <=30   | high   | no      | excellent     | no   |
| 31..40 | high   | no      | fair          | yes  |
| >40    | medium | no      | fair          | yes  |
| >40    | low    | yes     | fair          | yes  |
| >40    | low    | yes     | excellent     | no   |
| 31..40 | low    | yes     | excellent     | yes  |
| <=30   | medium | no      | fair          | no   |
| <=30   | low    | yes     | fair          | yes  |
| >40    | medium | yes     | fair          | yes  |
| <=30   | medium | yes     | excellent     | yes  |
| 31..40 | medium | no      | excellent     | yes  |
| 31..40 | high   | yes     | fair          | yes  |
| >40    | medium | no      | excellent     | no   |
+--------+--------+---------+---------------+------+

[fedora7@master ~]$ python pysql.py
Number of YES entries:  9
Number of NO entries:  5
--------------------NAIVE BAYES CLASSIFICATION SYSTEM------------------------
Give age: <=30
Give income: medium
Give student (Yes/No): yes
Give credit rating: fair
0.0282186948854
0.00685714285714

You can buy a Computer!

[fedora7@master ~]$ 
"""
