#include <iostream>
#include <stdlib.h>
#include <ctime>
#include <time.h>
#include <omp.h>
#include <fstream>
using namespace std;

int a[10000];
int comparision = 0;

void sortList(int n){
	int i,j;
	int temp;
	#pragma omp parallel for collapse(2)
	for(i=1;i<n;i++)
	    {
	        for(j=0;j<(n-1);j++)
	            if(a[j]>a[j+1])
	            {
	                temp=a[j];
	                a[j]=a[j+1];
	                a[j+1]=temp;
	            }
	    }
}


int binarySearch(int arr[], int left, int right, int key){
	   if(right >= left)
	   {
	        int mid = left + (right - left)/2;

	        if(arr[mid] == key){
			comparision++;
	        	return mid;
		}

	        if(arr[mid] > key){
			comparision++;
	        	return binarySearch(arr, left, mid-1, key);
		}

		comparision++;
	        return binarySearch(arr, mid+1, right, key);
	   }

	   return -1;
}

int main() {
	int n,i,ch,key;
	float time_elapsed;
	ofstream myfile;

	cout<<"\nEnter how many elements: ";
	cin>>n;

	for(i=0;i<n;i++){
		a[i] = (rand() % 10000) + 1;
			
	}

	sortList(n);

	myfile.open("output.txt");

	cout<<"\nThe entered list is: \n";
	for(i=0;i<n;i++){
		cout<<a[i];
		cout<<"\t";
	}

	for(i=0;i<n;i++){
		myfile<<a[i]<<"\t";
	}
	
	cout<<"\n\nN/2 is : "<<a[n/2];

	cout<<"\nEnter number to search from the sorted list: ";
	cin>>key;
	
	clock_t c_start = clock();
	int result = binarySearch(a,0,n-1,key);
	clock_t c_end = clock();
	time_elapsed = (c_end - c_start);
	if(result == -1){
		cout<<"\nElement not present in the array.\nNo.of Comparisions = "<<comparision;
		cout<<"\nCPU time = "<<time_elapsed<<" secs";
		cout<<"\nWORST Case.";
	}
	
	else{
		cout<<"\nElement present at index: "<<result;
		cout<<"\nNo of comparisions = "<<comparision;
		if(comparision == 1){
			cout<<"\nBEST Case.";
		}
		else
			cout<<"\nAVERAGE Case.";
		cout<<"\nCPU time = "<<time_elapsed<<" msecs";
	}

	cout<<"\n\n";
	return 0;
}


/* OUTPUT-----------------------------------------------------------

[fedora9@localhost Downloads]$ g++ -fopenmp binarySearch.cpp
[fedora9@localhost Downloads]$ ./a.out

Enter how many elements: 500

The entered list is: 
13	  13	  28	  60	 98	 281	337	337	
379	 493	 493	 541	571	 676	710	
724	 796	 887	1012	1012	1156	
1156	1238	1238	1314	1394	1422	1475	1649	
1649	1660	1730	1861	1747	1861	1747	1874	
1937	1747	1973	1747	1973	2037	2184	2184	
2228	2306	2337	2354	2363	2363	2498	2498	
2505	2568	2601	2601	2619	2652	2755	2755	
2755	2778	2778	2461	2778	2863	2863	2955	
3059	3070	3304	3318	3318	3368	3369	3427	
3452	3527	3585	3744	3751	3785	3785	3785	
3896	3930	2135	3930	4287	4371	4429	1693	
4444	4482	4482	4482	4482	4568	2135	4795	
4795	4893	4893	4915	4920	505	4920	4931	
5012	5124	965	3178	5129	5199	3178	5212	
5274	290	3145	5322	5369	5369	5369	5404	
3145	5435	5437	5569	5662	5668	5733	5783	
5789	5789	5857	5885	5885	5885	5937	5937	
6125	6125	6128	6227	6227	6227	6227	6227	
6229	6229	6305	6305	6430	6430	6438	6438	
6492	6506	6620	6650	6650	6716	6841	6841	
6841	6841	6916	6966	6966	6966	6988	6988	
7035	7132	7179	7282	7282	7302	7446	7670	
7754	7754	7764	7764	7765	7765	7765	7982	
8037	8095	8168	8168	8168	8168	8168	8168	
8168	8168	8168	8207	8207	8229	8316	8316	
8316	8336	8336	8336	8366	8391	8391	8391	
8441	8457	8457	8457	8538	8538	8538	8538	
8543	8582	8625	8661	8691	8777	8805	8815	
8830	8830	8859	8859	8873	8981	8981	8981	
9173	9229	9300	9356	9356	9356	9380	9471	
9471	9471	9471	9504	9504	9504    9530	9583	
9669	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9677	9677	
9677	9677	9677	9677	9677	9677	9690	9690	
9690	9690	9690	9690	9690	9690	9690	9690	
9690	9690	9690	9690	9690	9690	9690	9690	
9690	9690	9690	9690	9690	9690	9690	9690	
9690	9690	9690	9690	9690	9690	9690	9690	
9690	9690	9690	9690	9690	9690	9690	9690	
9690	9690	9690	9690	9709	9709	9709	9709	
9709	9709	9709	9709	9709	9709	9709	9709	
9709	9709	9709	9709	9709	9709	9709	9709	
9709	9709	9709	9709	9709	9709	9709	9709	
9709	9709	9709	9709	9709	9755	9757	9757	
9757	9757	9773	9798	9798	9798	9798	9798	
9803	9803	9812	9812	9812	9842	9842	9842	
9842	9842	9842	9842	9842	9842	9842	9842	
9842	9842	9842	9842	9842	9842	9842	9842	
9842	9842	9842	9842	9842	9842	9842	9842	
9842	9842	9842	9842	9842	9842	9842	9860	
9860	9905	9918	9933	9933	9957	9959	



N/2 is : 9504

Enter number to search from the sorted list: 9504

Element present at index: 249
No of comparisions = 1
BEST Case.

CPU time = 2 msecs

*/
