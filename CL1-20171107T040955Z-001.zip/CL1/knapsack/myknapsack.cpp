#include <queue>
#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

struct node
{
    int level;
    int profit;
    int weight;
    int bound;
};

void knapsack(float *p,float *w, float * index, int knapsack_capacity,int n){
	node a,b,c;

	a.level = -1;
	a.profit = 0;
	a.weight = 0;

	for(int i=0;i<=n;i++){
		if(a.level == -1){
			//Calculating Initial upper bound.
			a.bound = a.profit + (knapsack_capacity-a.weight)*(p[a.level+1])/(w[a.level+1]);
			cout<<"\nInitial bound: "<<a.bound;
			a.level++;
		}
		else if (i==n){
			b = a;
			c = a;
			//---------------Calculating b--------------------------
			b.weight = b.weight + w[b.level];
			b.profit = b.profit + p[b.level];
			b.bound = b.profit + 0;
			cout<<"\nb.bound = "<<b.bound;
			//---------------Calculating c--------------------------
			c.bound = c.profit + 0;
			cout<<"\nc.bound = "<<c.bound;
			c.level++;
			if(b.bound > c.bound && b.weight<=knapsack_capacity){
				a = b;
				cout<<"\nNode I"<<(i)<<" included";
			}
			else{
				a = c;
				cout<<"\nNode I"<<(i)<<" excluded\n";
			}
		}
		else{
			b = a;//Include
			c = a;//Don't include
			//---------------Calculating b--------------------------
			b.weight = b.weight + w[b.level];
			b.profit = b.profit + p[b.level];
			b.bound = b.profit + (knapsack_capacity - b.weight)*(p[b.level+1])/(w[b.level+1]);
			cout<<"\nb.bound = "<<b.bound;
			b.level++;

			//---------------Calculating c--------------------------
			c.bound = c.profit + (knapsack_capacity - c.weight)*(p[c.level+1])/(w[c.level+1]);
			cout<<"\nc.bound = "<<c.bound;
			c.level++;
			if(b.bound > c.bound && b.weight<=knapsack_capacity){
				a = b;
				cout<<"\nNode I"<<(i)<<" included";
			}
			else{
				a = c;
				cout<<"\nNode I"<<(i)<<" excluded";
			}
		}
	}
}

void swap(float a, float b){
	float temp;
	temp = a;
	a = b;
	b = temp;
}

int main(){
	ifstream myfile;
	myfile.open("input.txt");
	int n,knapsack_capacity;
	//cout<<"\nEnter number of items: ";
	myfile>>n;

	float p[n],w[n],index[n];

	for(int i = 0; i < n; i++){
		//cout<<"\nEnter profit and weight of item number "<<(i+1)<<": ";
		myfile>>p[i];
		myfile>>w[i];
		index[i] = p[i]/w[i];
	} 

	for(int i=1;i<n;i++)
    {
        for(int j=0;j<(n-1);j++)
            if(index[j]>index[j+1])
            {
               swap(index[j],index[j+1]);
               swap(p[j],p[j+1]);
               swap(w[j],w[j+1]);
            }
    }

	cout<<"\nYou entered the following:";

	for(int i = 0; i < n; i++){
		cout<<"\n"<<p[i];
		cout<<"\t"<<w[i];
		cout<<"\t"<<index[i];
	}



	myfile>>knapsack_capacity;

	knapsack(p,w,index,knapsack_capacity,n);

	myfile.close();

}